package com.slc.android.sceneliner_1_0.app;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ViewFlipper;

import com.slc.android.sceneliner_1_0.R;
import com.slc.android.sceneliner_1_0.control.AppController;

import java.util.ArrayList;


public class SLBrowseActivity extends ActionBarActivity {

    private ArrayList<String> regionList;
    private ArrayList<String> perRegionBusinessList;
    private ViewFlipper displayChanger;
    private ListView regionsListView;
    private ListView perRegionBusinessListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slbrowse_region);

        displayChanger = (ViewFlipper) findViewById(R.id.browserFlipper);

        regionList = AppController.getRegionsList();
        regionsListView = (ListView) findViewById(R.id.regionBrowseScreenListView);

        ArrayAdapter<String> regionListAdapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_1, regionList);
        regionsListView.setAdapter(regionListAdapter);
        regionsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    ArrayAdapter<String> regionsList = (ArrayAdapter<String>) parent.getAdapter().getItem(position);
                    String targetRegion = regionsList.getItem(position);
                    populateRegionListAndSwitchView(targetRegion);
                }
            }
        });



    }

    private void populateRegionListAndSwitchView(String region){
        AppController.setCurrentRegion(region);
        perRegionBusinessList = AppController.getBusinessForRegion(region);

        perRegionBusinessListView = (ListView) findViewById(R.id.businessBrowseScreenListView);
        ArrayAdapter<String> businessListAdapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_1, perRegionBusinessList);
        perRegionBusinessListView.setAdapter(businessListAdapter);
        perRegionBusinessListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    ArrayAdapter<String> businessList = (ArrayAdapter<String>) parent.getAdapter().getItem(position);
                    String targetBusiness = businessList.getItem(position);
                    setTargetBusinessAndStartPlayer(targetBusiness);
                }
            }

        });
    }

    private void setTargetBusinessAndStartPlayer(String business) {
        AppController.set
        Intent intent = new Intent(this, SLPlayerActivity.class);

    }

    private void regionSelected(String region) {
        perRegionBusinessList = AppController.getBusinessForRegion(region);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_slbrowse, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
