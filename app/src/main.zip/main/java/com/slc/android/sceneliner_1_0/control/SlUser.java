package com.slc.android.sceneliner_1_0.control;

import android.os.Parcel;
import android.os.Parcelable;

import com.parse.ParseUser;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Robert Gruemmer on 6/3/2015.
 */
class SlUser implements Parcelable {
    ParseUser curUser;
    String id;
    HashMap<String, ArrayList<String>> favorites; //region, favorites

    public SlUser(ParseUser usr){
        curUser = usr;
        id = (String) usr.get("objectId");
    }

    public SlUser(Parcel in) {

    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

    }

    public static final Parcelable.Creator<SlUser> CREATOR = new Parcelable.Creator<SlUser>() {
        public SlUser createFromParcel(Parcel in) {
            return new SlUser(in);
        }

        public SlUser[] newArray(int size) {
            return new SlUser[size];
        }
    };
}