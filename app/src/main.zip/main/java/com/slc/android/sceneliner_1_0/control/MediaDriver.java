package com.slc.android.sceneliner_1_0.control;

import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by Robert Gruemmer on 5/30/2015.
 */
public class MediaDriver implements MediaPlayer.OnErrorListener,
        MediaPlayer.OnCompletionListener, MediaPlayer.OnPreparedListener{

    private Context appContext;
    private SurfaceView surfaceView;
    private SurfaceHolder sHolder;

    private Timer timerController;
    private String sourceUrl;

    private MediaPlayer curMediaPlayer;
    private MediaPlayer nextMediaPlayer;
    private boolean firstPlay = true;

    public static final double DELAY_TO_UPDATE_IN_PERCENT_DURATION = .75;



    public MediaDriver(Context context, SurfaceView surface, String videoUrl) {
        appContext = context;
        surfaceView = surface;
        sourceUrl = videoUrl;
        sHolder = surfaceView.getHolder();
        curMediaPlayer = null;
        nextMediaPlayer = null;
        timerController = new Timer();
        initializeMedia(curMediaPlayer);
    }


    private void initializeMedia(MediaPlayer mp) {
        Uri sourceUri = Uri.parse(sourceUrl);
        mp = new MediaPlayer();
        mp.setOnErrorListener(this);
        mp.setOnCompletionListener(this);
        mp.setLooping(false);

        while (sHolder.isCreating()) {
            Log.e("MEDIA_DRIVER", "SURFACE NOT CREATED YET!");
        }

        mp.setDisplay(sHolder);

        try {
            mp.setDataSource(appContext, sourceUri);
        } catch (IllegalArgumentException ex) {
            Log.e("MEDIA_DRIVER", "Failed to set data source: Illegal Argument Exception");
        } catch (SecurityException ex) {
            Log.e("MEDIA_DRIVER", "Failed to set data source: Security Exception");
        } catch (IllegalStateException ex) {
            Log.e("MEDIA_DRIVER", "Failed to set data source: Illegal State Exception");
        } catch (IOException ex) {
            Log.e("MEDIA_DRIVER", "Failed to set data source: I/O Exception");
        }

        if (firstPlay) {
            mp.prepareAsync();
        } else {
            mp.prepareAsync();
        }
    }




    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        return false;
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        curMediaPlayer.release();
        curMediaPlayer = nextMediaPlayer;
        curMediaPlayer.start();
    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        if (firstPlay) {
            mp.start();
            firstPlay = false;
        }
    }

    private void createTimerInterruptForUpdate(long delay) {
        TimerTask interruptTask = (TimerTask) new TimerInterruptTask();
        timerController.schedule(interruptTask, delay);
    }

    class TimerInterruptTask extends TimerTask {
        @Override
        public void run() {
            Log.v("MEDIA_DRIVER", "Interrupt Triggered.");
        }

    }
}
