package com.slc.android.sceneliner_1_0.control;

import android.os.Parcel;
import android.os.Parcelable;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import java.util.List;

/**
 * Created by Robert Gruemmer on 6/3/2015.
 */
class Business implements Parcelable {
    String name;
    String id;
    String region;
    String specials;
    String contactInfo;
    int numCameras;

    public Business(String id, String name, String region, String specials,
                    String contactInfo, int numCameras) {
        this.id = id;
        this.name = name;
        this.region = region;
        this.specials = specials;
        this.contactInfo = contactInfo;
        this.numCameras = numCameras;
    }

    public Business(Parcel in) {

    }

    public Business(String id) {
        this.id = id;
        getBusinessDetailsFromCloud();
    }

    private void getBusinessDetailsFromCloud() {
        ParseQuery<ParseUser> query = ParseUser.getQuery();
        query.whereEqualTo("objectId", id);
        query.findInBackground(new FindCallback<ParseUser>() {
            @Override
            public void done(List<ParseUser> businessList, ParseException e) {
                if (e == null) {
                    ParseUser business = businessList.get(0);
                    name = (String) business.get("BusinessName");
                    region = (String) business.get("Region");
                    specials = (String) business.get("specials");
                    contactInfo = (String) business.get("contactInfo");
                    numCameras = (Integer) business.get("numCameras");

                }
            }
        });
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

    }

    public static final Parcelable.Creator<Business> CREATOR = new Parcelable.Creator<Business>() {
        public Business createFromParcel(Parcel in) {
            return new Business(in);
        }

        public Business[] newArray(int size) {
            return new Business[size];
        }
    };
}