package com.slc.android.sceneliner_1_0.control;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;

import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

/**
 * Created by Robert Gruemmer on 6/1/2015.
 */
public class AppController implements Parcelable{

    private Context appContext;
    private String currentRegion;
    private CloudController.Business currentBusiness;

    private CloudController cloud;
    private MediaDriver mediaDriver;

    public static final String PARSE_APP_KEY = "qJBsxM22BwWCrK3OTO033bMteUxhaC2J2LzkgxBh";
    public static final String PARSE_CLIENT_KEY = "aKUCpkBjixCgauLeV9zlFr2DPrqgzdDRqEl1VFha";

    public AppController(Context context) {
        appContext = context;
        cloud = new CloudController(appContext, PARSE_APP_KEY, PARSE_CLIENT_KEY);
    }

    public boolean isUserLoggedIn() {
        return cloud.isUserLoggedInUser();
    }

    public void userLogin(String user, String pw) {
        cloud.login(user, pw);
    }

    public void userLogout() {
        cloud.logout();
    }

    public void createAccount(String user, String pw, String pwVerify, String email) {
        cloud.createAccount(user, pw, pwVerify, email);
    }

    public void deleteAccount() {
        cloud.deleteAccount();
    }

    public void updateFeedsMap() {
        cloud.updateFeedsMap();
    }

    public void setCurrentRegion(String region) {
        currentRegion = region;
    }


    public void setCurrentBusiness(String businessId) {
        currentBusiness = cloud.setCurrentBusiness(businessId);
    }

    public void startBusinessPlayerScreen(String businessId) {
        setCurrentBusiness(businessId);
    }

    public Set<String> getRegionsList() {
        return cloud.getRegionsList();
    }

    public Collection<CloudController.Business> getBusinessesForRegion(String region) {
        HashMap<String, CloudController.Business> perRegionBusinessMap =
                cloud.getPerRegionBusinessMap(region);
        return perRegionBusinessMap.values();
    }


    @Override
    public int describeContents() {
        return hashCode();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.

    }
}



