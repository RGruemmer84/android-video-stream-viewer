package com.slc.android.sceneliner_1_0.control;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.LogInCallback;
import com.parse.Parse;
import com.parse.ParseException;
import com.parse.ParseQuery;
import com.parse.ParseUser;
import com.parse.SignUpCallback;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

/**
 * Created by Robert Gruemmer on 5/30/2015.
 */

public class CloudController implements Parcelable{

    private Context appContext;
    private SlUser curSlUser = null;
    public HashMap<String, HashMap<String, Business>> businessMap;

    public CloudController(Parcel in) {

    }

    public CloudController(Context context, String appKey, String clientKey){
        appContext = context;
        Parse.enableLocalDatastore(context);
        Parse.initialize(context, appKey, clientKey);
    }
    
    public boolean isUserLoggedInUser(){
        if (curSlUser == null) {
            ParseUser curParseUser = ParseUser.getCurrentUser();
            if (curParseUser == null) {
                return false;
            } else {
                curSlUser = new SlUser(curParseUser);
                updateFeedsMap();
                return true;
            }
        } else
            return true;
    }


    public void login(String user, String pw) {
        ParseUser.logInInBackground(user, pw, new LogInCallback() {
            @Override
            public void done(ParseUser parseUser, ParseException e) {
                if (parseUser != null) {
                    Log.i("PARSE_LOGIN", "Logged in successfully");
                    updateFeedsMap();
                    curSlUser = new SlUser(parseUser);
                } else {
                    Log.e("PARSE_LOGIN", "Failed to login!");
                    CharSequence message = "Failed to login!";
                    Toast.makeText(appContext, message, Toast.LENGTH_SHORT);
                }
            }
        });

    }

    public void logout() {
        ParseUser.logOut();
        curSlUser = null;
    }

    public void createAccount(String user, String pw, String pwVerify, String email) {
        if (!pw.equals(pwVerify)) {
            Log.e("CREATE_ACCOUNT", "PASSWORD DOESN'T MATCH");
            CharSequence message = "Passwords don't match!";
            Toast.makeText(appContext, message, Toast.LENGTH_SHORT);
        } else {
            ParseUser pUser = new ParseUser();
            pUser.setUsername(user);
            pUser.setPassword(pw);
            pUser.setEmail(email);
            pUser.put("isProprietor", false);
            pUser.put("URL_0", "null");
            pUser.put("URL_1", "null");
            pUser.put("URL_2", "null");
            pUser.put("URL_3", "null");
            pUser.put("BusinessName", "null");
            pUser.put("Region", "null");

            pUser.signUpInBackground(new SignUpCallback() {
                public void done(ParseException e) {
                    if (e == null) {
                        Log.i("CREATE_ACCOUNT", "Account created successfully");
                        curSlUser = new SlUser(ParseUser.getCurrentUser());
                        updateFeedsMap();
                    } else {
                        Log.e("CREATE_ACCOUNT", "Unable to create account");
                        CharSequence message = "Problem creating account.  Contact Support";
                        Toast.makeText(appContext, message, Toast.LENGTH_SHORT);
                    }
                }
            });
        }
    }

    public void deleteAccount() {
        ParseQuery<ParseUser> query = ParseUser.getQuery();
        query.whereEqualTo("objectId", curSlUser.id);
        query.findInBackground(new FindCallback<ParseUser>() {

            public void done(List<ParseUser> parseUser, ParseException e) {
                if (e == null) {
                    ParseUser.deleteAllInBackground(parseUser);
                    curSlUser = null;
                }
            }
        });

    }

    public void updateFeedsMap() {
        businessMap = null;

        ParseQuery<ParseUser> query = ParseUser.getQuery();
        query.whereEqualTo("isProprietor", true);
        query.findInBackground(new FindCallback<ParseUser>() {

            public void done(List<ParseUser> businessOwners, ParseException e) {
                if (e == null) {
                    businessMap = new HashMap<String, HashMap<String, Business>>();

                    String region;
                    String businessName;
                    String id;
                    int numCameras;
                    String specials;
                    String contactInfo;

                    for (ParseUser businessOwner : businessOwners) {
                        region = (String) businessOwner.get("Region");
                        businessName = (String) businessOwner.get("BusinessName");
                        id = (String) businessOwner.get("objectId");
                        numCameras = (Integer) businessOwner.get("numCameras");
                        specials = (String) businessOwner.get("specials");
                        contactInfo = (String) businessOwner.get("contactInfo");

                        HashMap<String, Business> curRegionBusinessList = businessMap.get(region);

                        if (curRegionBusinessList == null)
                            curRegionBusinessList = new HashMap<String, Business>();

                        curRegionBusinessList.put(id, new Business(id, businessName, region, specials, contactInfo, numCameras));
                        businessMap.put(region, curRegionBusinessList);
                    }
                } else {
                    Log.e("CLOUD_CONTROLLER", "Failed to update Feeds List");
                    CharSequence message = "Failed to get business info from server";
                    Toast.makeText(appContext, message, Toast.LENGTH_SHORT);
                }
            }
        });
    }

    public boolean getFeedUpdateFlag(String businessId, final int feedNum){
        ParseQuery<ParseUser> query = ParseUser.getQuery();
        query.whereEqualTo("objectId", businessId);
        try {
            List<ParseUser> users = query.find();
            return users.get(0).getBoolean(String.format("FeedToggle_%d", feedNum));
        } catch (ParseException e) {
            Log.e("CLOUD_CONTROLLER", "Update Flag Query Failed.");
            e.printStackTrace();
            throw new NullPointerException();
        }

    }

    public Set<String> getRegionsList(){
        return businessMap.keySet();
    }

    public HashMap<String, Business> getPerRegionBusinessMap(String region) {
        return businessMap.get(region);
    }

    public Business setCurrentBusiness(String id){
        return new Business(id);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

    }

    public static final Parcelable.Creator<CloudController> CREATOR = new Parcelable.Creator<CloudController>() {
        public CloudController createFromParcel(Parcel in) {
            return new CloudController(in);
        }

        public CloudController[] newArray(int size) {
            return new CloudController[size];
        }
    };







}
